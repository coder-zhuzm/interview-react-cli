# vue-code

使用 vue-cli 创建的 vue3 项目，包括 vue-router

## 前提

安装 nodejs v14+ ，安装 `npm` 或 `yarn`

## 运行

- 安装依赖：`npm install` 或 `yarn install`
- 本地运行：`npm run serve` 或 `yarn serve`
