<template>
    <p>async component child</p>
</template>

<script>
export default {
    name: 'Child',
}
</script>
