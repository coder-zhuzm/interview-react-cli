<template>
    <p>Level3 {{info}}</p>
</template>

<script>
export default {
    name: 'Level3',
    inject: ['info']
}
</script>