/**
 * @description index test
 * @author 双越老师
 */

describe('index', () => {
    it('index', () => {
        expect(1).toBe(1)
    })
})
