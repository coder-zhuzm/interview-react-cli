# js-code

## 前提

安装 nodejs v14+ ，安装 `npm` 或 `yarn`

## 运行

- 安装依赖：`npm install` 或 `yarn install`
- 本地运行：`npm run dev` 或 `yarn dev` ，浏览器访问 `http://localhost:3000/`
