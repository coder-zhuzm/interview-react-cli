# html css code

## 前提

安装 nodejs v14+ ，安装 `npm` 或 `yarn`

## 运行

安装 http-server `npm install http-server -g`

运行 `http-server -p 8881` ，然后浏览器访问 `http://localhost:8881/`
