# Getting Started with Create React App

使用 create-react-app 创建的 react 项目

## 前提

安装 nodejs v14+ ，安装 `npm` 或 `yarn`

## 运行

- 安装依赖：`npm install` 或 `yarn install`
- 本地运行：`npm start` 或 `yarn start`
