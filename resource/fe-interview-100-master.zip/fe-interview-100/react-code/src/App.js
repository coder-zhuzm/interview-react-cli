// import SimpleTodos from "./components/SimpleTodos"
// import ErrorDemoFunctional from "./components/ErrorDemo/FunctionalDemo"
// import ErrorDemoClass from "./components/ErrorDemo/ClassDemo"
// import SetStateDemo from './components/SetStateDemo'
import SetStateDemo2 from './components/SetStateDemo2'

function App() {
  return (
    <>
      <h1>App</h1>
      <hr/>

      {/* <SimpleTodos></SimpleTodos> */}
      {/* <ErrorDemoFunctional></ErrorDemoFunctional> */}
      {/* <ErrorDemoClass></ErrorDemoClass> */}
      {/* <SetStateDemo/> */}
      <SetStateDemo2/>
    </>
  );
}

export default App;
