# nodejs-code

## 前提

安装 nodejs v14+ ，安装 `npm` 或 `yarn`

## 运行

- 安装 `npm install` 或 `yarn install`
- 执行 `node src/xxx.js`
